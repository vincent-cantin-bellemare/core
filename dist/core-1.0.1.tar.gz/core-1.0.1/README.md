# Example Package
ln -s /packages/core/src/core /code/core


This is a simple example package. You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.